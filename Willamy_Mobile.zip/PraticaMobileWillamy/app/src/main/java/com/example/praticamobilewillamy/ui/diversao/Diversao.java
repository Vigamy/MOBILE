package com.example.praticamobilewillamy.ui.diversao;

import android.content.Intent;
import android.os.Bundle;
import android.util.JsonReader;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.example.praticamobilewillamy.Api;
import com.example.praticamobilewillamy.MainActivity;
import com.example.praticamobilewillamy.R;
import com.example.praticamobilewillamy.model.Meme;
import com.example.praticamobilewillamy.model.MemeResponse;
import com.example.praticamobilewillamy.ui.surpresa.Surpresa;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Diversao extends Fragment {

    Retrofit retrofit;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_diversao, container, false);

        ImageView fun_fact = view.findViewById(R.id.fun_fact);
        ImageView to_be = view.findViewById(R.id.to_be);

        Bundle bundle = new Bundle();

        fun_fact.setOnClickListener(v -> {
            bundle.putBoolean("Botao", true);
            Toast.makeText(getContext(), "meme", Toast.LENGTH_SHORT).show();
        });

        to_be.setOnClickListener(v -> {
            Toast.makeText(getContext(), "surpresa", Toast.LENGTH_SHORT).show();
            bundle.putBoolean("Botao", false);
        });

        return view;

    }
}