package com.example.praticamobilewillamy.model;

public class Character {

    private String sentence;
    private Character character;

    // Getters e Setters
    public String getSentence() {
        return sentence;
    }

    public void setSentence(String sentence) {
        this.sentence = sentence;
    }

    public Character getCharacter() {
        return character;
    }

    public void setCharacter(Character character) {
        this.character = character;
    }

}