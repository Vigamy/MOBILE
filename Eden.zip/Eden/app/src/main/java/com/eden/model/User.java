package com.eden.model;

public class User {

    public String email;
    public String senha;

    public User() {
    }
    public User(String email, String senha) {
        this.email = email;
        this.senha = senha;
    }

}
