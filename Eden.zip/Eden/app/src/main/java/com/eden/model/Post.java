package com.eden.model;

public class Post {

}
